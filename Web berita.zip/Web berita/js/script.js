$(document).ready(function() {
  var state = false,
    links = $(".navbar-responsive__link");
  $("#nav-icon3").click(function() {
    $(this).toggleClass("open");
    if (!state) {
      $(".nav_r").css("transform", "translate3d(0,0,0)");
      state = true;
    } else {
      $(".nav_r").css("transform", "translate3d(-100%,0,0)");
      state = false;
    }
  });
  $.each(links, function(index, value) {
    value.addEventListener("click", function() {
      if (!state) {
        $(".nav_r").css("transform", "translate3d(0,0,0)");
        state = true;
      } else {
        $(".nav_r").css("transform", "translate3d(-100%,0,0)");
        state = false;
      }
      $("#nav-icon3").removeClass("open");
    });
  });
});




// teks animasi on refresh
document.addEventListener("DOMContentLoaded", function () {
    const box = document.querySelector("#teks");

    window.addEventListener("scroll", function () {
        const boxRect = box.getBoundingClientRect();
        const windowBottom = window.innerHeight;
        const scrollPosition = window.scrollY;

        // Atur kondisi untuk menghilangkan elemen saat digulir keluar dari tampilan
        if (boxRect.bottom < 0 || boxRect.top > windowBottom) {
            box.style.opacity = 0;
        } else {
            box.style.opacity = 1;
        }
        // Atur kondisi untuk memicu animasi saat elemen menjadi terlihat di layar
        if (scrollPosition > 100) {
            box.style.opacity = 1;
            box.style.transform = "translateX(0)";
        }
    });
});

// teks animasi ngetik
document.addEventListener('DOMContentLoaded',function(event){
  // array with texts to type in typewriter
  var dataText = [ "Learn all about what's topical from the outside world"];
  
  // type one text in the typwriter
  // keeps calling itself until the text is finished
  function typeWriter(text, i, fnCallback) {
    // chekc if text isn't finished yet
    if (i < (text.length)) {
      // add next character to h1
     document.querySelector(".animation_judul").innerHTML = text.substring(0, i+1) +'<span class="write_anime" aria-hidden="true"></span>';

      // wait for a while and call this function again for next character
      setTimeout(function() {
        typeWriter(text, i + 1, fnCallback)
      }, 100);
    }
    // text finished, call callback if there is a callback function
    else if (typeof fnCallback == 'function') {
      // call callback after timeout
      setTimeout(fnCallback, 700);
    }
  }
  // start a typewriter animation for a text in the dataText array
   function StartTextAnimation(i) {
     if (typeof dataText[i] == 'undefined'){
        setTimeout(function() {
          StartTextAnimation(0);
        }, 20000);
     }
     // check if dataText[i] exists
    if (i < dataText[i].length) {
      // text exists! start typewriter animation
     typeWriter(dataText[i], 0, function(){
       // after callback (and whole text has been animated), start next text
       StartTextAnimation(i + 1);
     });
    }
  }
  // start the text animation
  StartTextAnimation(0);
});

